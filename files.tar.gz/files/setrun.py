# setrun.py for AVAC 4: version = 1.0
"""
Module to set up run time parameters for Clawpack.

The values set in the function setrun are then written out to data files
that will be read in by the Fortran code.

"""

from __future__ import absolute_import
from __future__ import print_function
import os
import numpy as np
from clawpack.geoclaw import fgmax_tools
from clawpack.geoclaw import fgout_tools
from pathlib import Path
from yaml import safe_load

projdir = Path(__file__).parents[0]
with open(projdir / "AVAC_configuration.yaml") as file:
    configuration = safe_load(file)
    Files = configuration["file_names"]
    Rheol = configuration["rheology"]
    DEM   = configuration["dem_extent"]
    Param = configuration["computation"]
    OUT   = configuration["output"]
    Movie = configuration["animation"]
    
    
 

#------------------------------
def setrun(claw_pkg='geoclaw'):
#------------------------------

    """
    Define the parameters used for running Clawpack.

    INPUT:
        claw_pkg expected to be "geoclaw" for this setrun.

    OUTPUT:
        rundata - object of class ClawRunData

    """

    from clawpack.clawutil import data

    assert claw_pkg.lower() == 'geoclaw',  "Expected claw_pkg = 'geoclaw'"

    num_dim = 2
    rundata = data.ClawRunData(claw_pkg, num_dim)

    #------------------------------------------------------------------
    # GeoClaw specific parameters:
    #------------------------------------------------------------------
    rundata = setgeo(rundata)

    #------------------------------------------------------------------
    # Standard Clawpack parameters to be written to claw.data:
    #   (or to amr2ez.data for AMR)
    #------------------------------------------------------------------
    clawdata = rundata.clawdata  # initialized when rundata instantiated


    # Set single grid parameters first.
    # See below for AMR parameters.


    # ---------------
    # Spatial domain:
    # ---------------

    # Number of space dimensions:
    clawdata.num_dim = num_dim


    # Lower and upper edge of computational domain:
    clawdata.lower[0] = DEM['xmin']
    clawdata.upper[0] = DEM['xmax']

    clawdata.lower[1] = DEM['ymin']
    clawdata.upper[1] = DEM['ymax']
	 
    # Number of grid cells: Coarsest grid
    clawdata.num_cells[0] = int((DEM['xmax']-DEM['xmin'])/Param['domain_cell'])
    clawdata.num_cells[1] = int((DEM['ymax']-DEM['ymin'])/Param['domain_cell'])
    

    # ---------------
    # Size of system:
    # ---------------
    # Number of equations in the system:
    clawdata.num_eqn = 3
    # Number of auxiliary variables in the aux array (initialized in setaux)
    clawdata.num_aux = 1
    # Index of aux array corresponding to capacity function, if there is one:
    clawdata.capa_index = 0

    # -------------
    # Initial time:
    # -------------
    clawdata.t0 = 0.0

    # Restart from checkpoint file of a previous run?
    # If restarting, t0 above should be from original run, and the
    # restart_file 'fort.chkNNNNN' specified below should be in 
    # the OUTDIR indicated in Makefile.
    clawdata.restart      = False            # True to restart from prior results
    clawdata.restart_file = 'fort.chk00006'  # File to use for restart data

    # -------------
    # Output times:
    #--------------
    # Specify at what times the results should be written to fort.q files.
    # Note that the time integration stops after the final output time.
    # The solution at initial time t0 is always written in addition.
    clawdata.output_style = 1

    if clawdata.output_style==1:
        # Output nout frames at equally spaced times up to tfinal:
        clawdata.num_output_times = Param['nb_simul']
        clawdata.tfinal           = Param['t_max']
        clawdata.output_t0        = True  # output at initial (or restart) time?

    elif clawdata.output_style == 2:
        # Specify a list of output times.
        clawdata.output_times = [0.5, 1.0]

    elif clawdata.output_style == 3:
        # Output every iout timesteps with a total of ntot time steps:
        clawdata.output_step_interval = 1
        clawdata.total_steps = 1
        clawdata.output_t0 = True
        
    # --------------
    # Output format:
    #---------------
    clawdata.output_format = OUT['output_format']      # 'ascii', 'binary32" "binary64"

    clawdata.output_q_components   = 'all'   # could be list such as [True,True]
    clawdata.output_aux_components = [True]  # could be list
    clawdata.output_aux_onlyonce   = False   # output aux arrays only at t0. False required for post process in jupyter

    # ---------------------------------------------------
    # Verbosity of messages to screen during integration:
    # ---------------------------------------------------
    # The current t, dt, and cfl will be printed every time step
    # at AMR levels <= verbosity.  Set verbosity = 0 for no printing.
    #   (E.g. verbosity == 2 means print only on levels 1 and 2.)
    clawdata.verbosity = OUT['verbosity']

    # --------------
    # Time stepping:
    # --------------
    # if dt_variable==1: variable time steps used based on cfl_desired,
    # if dt_variable==0: fixed time steps dt = dt_initial will always be used.
    clawdata.dt_variable = True

    # Initial time step for variable dt.
    clawdata.dt_initial = 0.01 # If dt_variable==0 then dt=dt_initial for all steps:
    clawdata.dt_max     = 1e+99 # Max time step to be allowed if variable dt used:

    # Desired Courant number if variable dt used, and max to allow without
    # retaking step with a smaller dt:
    clawdata.cfl_desired = Param['cfl_target']
    clawdata.cfl_max     = Param['cfl_max']

    # Maximum number of time steps to allow between output times:
    clawdata.steps_max   = Param['max_iter']
 
    # ------------------
    # Method to be used:
    # ------------------
    # Order of accuracy:  1 => Godunov,  2 => Lax-Wendroff plus limiters
    clawdata.order = 2
    
    # Use dimensional splitting? (not yet available for AMR)
    clawdata.dimensional_split = 'unsplit'
    
    # For unsplit method, transverse_waves can be 
    #  0 or 'none'      ==> donor cell (only normal solver used)
    #  1 or 'increment' ==> corner transport of waves
    #  2 or 'all'       ==> corner transport of 2nd order corrections too
    clawdata.transverse_waves = 2

    # Number of waves in the Riemann solution:
    clawdata.num_waves = 3
    
    # List of limiters to use for each wave family:  
    # Required:  len(limiter) == num_waves
    # Some options:
    #   0 or 'none'     ==> no limiter (Lax-Wendroff)
    #   1 or 'minmod'   ==> minmod
    #   2 or 'superbee' ==> superbee
    #   3 or 'mc'       ==> MC limiter
    #   4 or 'vanleer'  ==> van Leer
    clawdata.limiter = ['mc', 'mc', 'mc']

    clawdata.use_fwaves = True    # True ==> use f-wave version of algorithms
    
    # Source terms splitting:
    #   src_split == 0 or 'none'    ==> no source term (src routine never called)
    #   src_split == 1 or 'godunov' ==> Godunov (1st order) splitting used, 
    #   src_split == 2 or 'strang'  ==> Strang (2nd order) splitting used,  not recommended.
    clawdata.source_split = 'godunov'


    # --------------------
    # Boundary conditions:
    # --------------------
    # Number of ghost cells (usually 2)
    clawdata.num_ghost = 2

    # Choice of BCs at xlower and xupper:
    #   0 => user specified (must modify bcN.f to use this option)
    #   1 => extrapolation (non-reflecting outflow)
    #   2 => periodic (must specify this at both boundaries)
    #   3 => solid wall for systems where q(2) is normal velocity

    clawdata.bc_lower[0] = Param['boundary']
    clawdata.bc_upper[0] = Param['boundary']
    clawdata.bc_lower[1] = Param['boundary']
    clawdata.bc_upper[1] = Param['boundary']

    # Specify when checkpoint files should be created that can be
    # used to restart a computation.
    clawdata.checkpt_style = 0

    if clawdata.checkpt_style == 0:
        # Do not checkpoint at all
        pass

    elif np.abs(clawdata.checkpt_style) == 1:
        # Checkpoint only at tfinal.
        pass

    elif np.abs(clawdata.checkpt_style) == 2:
        # Specify a list of checkpoint times.  
        clawdata.checkpt_times = [0.1,0.15]

    elif np.abs(clawdata.checkpt_style) == 3:
        # Checkpoint every checkpt_interval timesteps (on Level 1)
        # and at the final time.
        clawdata.checkpt_interval = 5

    # ---------------
    # AMR parameters:
    # ---------------
    amrdata = rundata.amrdata
    
    # maximum size of patches in each direction (matters in parallel):
    amrdata.max1d = 60

    # max number of refinement levels:
    amrdata.amr_levels_max = Param['refinement']

    # List of refinement ratios at each level (length at least mxnest-1)
    amrdata.refinement_ratios_x = [2,4,8]
    amrdata.refinement_ratios_y = [2,4,8]
    amrdata.refinement_ratios_t = [2,4,8]

    # Specify type of each aux variable in amrdata.auxtype.
    # This must be a list of length maux, each element of which is one of:
    #   'center',  'capacity', 'xleft', or 'yleft'  (see documentation).
    amrdata.aux_type = ['center']

    # Flag using refinement routine flag2refine rather than richardson error
    amrdata.flag_richardson = False    # use Richardson?
    amrdata.flag2refine     = True

    # steps to take on each level L between regriddings of level L+1:
    amrdata.regrid_interval = 3

    # width of buffer zone around flagged points:
    # (typically the same as regrid_interval so waves don't escape):
    amrdata.regrid_buffer_width  = 2

    # clustering alg. cutoff for (# flagged pts) / (total # of cells refined)
    # (closer to 1.0 => more small grids may be needed to cover flagged cells)
    amrdata.clustering_cutoff = 0.700000

    # print info about each regridding up to this level:
    amrdata.verbosity_regrid = 0  

    #  ----- For developers ----- 
    # Toggle debugging print statements:
    amrdata.dprint = False      # print domain flags
    amrdata.eprint = False      # print err est flags
    amrdata.edebug = False      # even more err est flags
    amrdata.gprint = False      # grid bisection/clustering
    amrdata.nprint = False      # proper nesting output
    amrdata.pprint = False      # proj. of tagged points
    amrdata.rprint = False      # print regridding summary
    amrdata.sprint = False      # space/memory output
    amrdata.tprint = False      # time step reporting each level
    amrdata.uprint = False      # update/upbnd reporting
    
    # More AMR parameters can be set -- see the defaults in pyclaw/data.py

    # == setregions.data values ==
    regions = rundata.regiondata.regions
    # to specify regions of refinement append lines of the form
    #  [minlevel,maxlevel,t1,t2,x1,x2,y1,y2]
    #regions.append([1, 1, 0., 1.e10, 925720,927160., 6451140.,6452155.])
    # if AddSetRun.refinement_area == 1:
       # regions.append([1, 2, 0., 1.e10, AddSetRun.xmin, \
       # AddSetRun.xmax, AddSetRun.ymin, AddSetRun.ymax])
    # elif AddSetRun.refinement_area == 2:
       # regions.append([1, 2, 0., 1.e10, AddZoom.x_zoom_min, \
       # AddZoom.x_zoom_max, AddZoom.y_zoom_min, AddZoom.y_zoom_max])    
       
 
       
    #regions.append([2, 3, 3., 1.e10,   52., 72.,   52., 72.])
    #regions.append([2, 3, 3., 1.e10,   75., 95.,   -10.,  10.])
    #regions.append([2, 4, 3.4, 1.e10,   57., 68.,   57., 68.])
    #regions.append([2, 4, 3.4, 1.e10,   83., 92.,   -4.,  4.])
 

    # == setgauges.data values ==
    # for gauges append lines of the form  [gaugeno, x, y, t1, t2]
    # rundata.gaugedata.add_gauge()

    # gauges along x-axis:
    # gaugeno = 0
    # for r in np.linspace(-10, 10., 10):
    #     gaugeno = gaugeno+1
    #     x = r + .001  # shift a bit away from cell corners
    #     y = .001
     #    rundata.gaugedata.gauges.append([gaugeno, x, y, 0., 1e10])


    ###############################
    #   fgmax_grids.data values   #  
    ###############################

    # set num_fgmax_val = 1 to save only max depth,
    #                     2 to also save max speed,
    #                     5 to also save max hs,hss,hmin
    rundata.fgmax_data.num_fgmax_val = 2  # Save depth and speed see https://www.clawpack.org/fgmax.html

    fgmax_grids = rundata.fgmax_data.fgmax_grids  # empty list to start

    # Now append to this list objects of class fgmax_tools.FGmaxGrid
    # specifying any fgmax grids.

    # Points on a uniform 2d grid:
    dx_fine = Param['domain_cell']  # grid resolution at finest level

    fg = fgmax_tools.FGmaxGrid()
    fg.point_style = 2  # uniform rectangular x-y grid
    fg.x1 = clawdata.lower[0]
    fg.x2 = clawdata.upper[0]
    fg.y1 = clawdata.lower[1]
    fg.y2 = clawdata.upper[1]
    fg.dx = dx_fine
    fg.tstart_max = 1.      # when to start monitoring max values
    fg.tend_max   = Param['t_max']       # when to stop monitoring max values
    fg.dt_check   = OUT['delta_t']     # target time (sec) increment between updating 
                              # max values
    fg.min_level_check = amrdata.amr_levels_max    # which levels to monitor max on
    fg.arrival_tol = 1.e-2    # tolerance for flagging arrival

    fg.interp_method = 0      # 0 ==> pw const in cells, recommended
    fgmax_grids.append(fg)    # written to fgmax_grids.data

 


    # == fgout_grids.data values ==
    # NEW IN v5.9.0
    # Set rundata.fgout_data.fgout_grids to be a list of
    # objects of class clawpack.geoclaw.fgout_tools.FGoutGrid:
    fgout_grids = rundata.fgout_data.fgout_grids  # empty list initially

    fgout               = fgout_tools.FGoutGrid()
    fgout.fgno          = 1              # for listing the files see doc
    fgout.point_style   = 2       # will specify a 2d grid of points
    fgout.output_format = OUT['output_format']  # 4-byte, float32
    fgout.nx = int((DEM['xmax']-DEM['xmin'])/Param['domain_cell'])
    fgout.ny = int((DEM['ymax']-DEM['ymin'])/Param['domain_cell'])
    fgout.x1 = DEM['xmin'] #+ dx_fine/2.  # specify edges (fgout pts will be cell centers)
    fgout.x2 = DEM['xmax'] #- dx_fine/2.
    fgout.y1 = DEM['ymin'] #+ dx_fine/2
    fgout.y2 = DEM['ymax'] #- dx_fine/2.
    fgout.tstart = 0.
    fgout.tend   = Param['t_max']
    fgout.nout   = Movie['n_out']
    fgout_grids.append(fgout)    # written to fgout_grids.data

    #########################
    # setprob data parameters
    # Points on a uniform 2d grid:
	
    if Rheol["model"]=='Voellmy':
        coulomb=0
    else:
        coulomb=1
	
    probdata = rundata.new_UserData(name='probdata',fname='setprob.data')
    
    probdata.add_param('rho', Rheol["rho"],  'snow density')   
    probdata.add_param('xi', Rheol["xi"],  'xi')
    probdata.add_param('mu', Rheol["mu"],  'mu')
    probdata.add_param('threshold', Rheol["u_cr"],  'u_cr')
    probdata.add_param('beta_slope', Rheol["beta"],  'beta_slope')
    probdata.add_param('model', coulomb,  'The rheological model: 0 -> Voellmy, 1-Coulomb')
    probdata.add_param('tau_c', 1,  'tau_cr')


    return rundata
    # end of function setrun
    # ----------------------





 






#-------------------
def setgeo(rundata):
#-------------------
    """
    Set GeoClaw specific runtime parameters.
    For documentation see ....
    """

    try:
        geo_data = rundata.geo_data
    except:
        print("*** Error, this rundata has no geo_data attribute")
        raise AttributeError("Missing geo_data attribute")


            
    # == Physics ==
    geo_data.gravity           = 9.81
    geo_data.coordinate_system = 1 #Cartesian
    geo_data.earth_radius      = 6367.5e3

    # == correctif val d'isère
    rundata.topo_data.topo_missing = DEM['nodata_value']

    # == Forcing Options
    geo_data.coriolis_forcing = False

    # == Algorithm and Initial Conditions ==
    geo_data.sea_level           = 0.0
    geo_data.dry_tolerance       = Param['dry_limit']
    geo_data.friction_forcing    = True
    geo_data.manning_coefficient = 0.025
    geo_data.friction_depth      = 20.0

    # Refinement data
    refinement_data                = rundata.refinement_data
    refinement_data.wave_tolerance = 1.e-2
    refinement_data.deep_depth     = 1e2
    refinement_data.max_level_deep = 3
    refinement_data.variable_dt_refinement_ratios = True

    # == settopo.data values ==
    topo_data = rundata.topo_data
    topo_file = Files['topofile'] # for topography, append lines of the form
    topo_type = Files['type_dem'] 
    topo_data.topofiles.append([topo_type, 1, 3, 0., 1.e10, topo_file]) #    [topotype, minlevel, maxlevel, t1, t2, fname]

    # == setdtopo.data values ==
    dtopo_data = rundata.dtopo_data
    # for moving topography, append lines of the form :   (<= 1 allowed for now!)
    #   [topotype, minlevel,maxlevel,fname]

    # == setqinit.data values ==
    rundata.qinit_data.qinit_type = Files['type_init'] 
    rundata.qinit_data.qinitfiles = []
    # for qinit perturbations, append lines of the form: (<= 1 allowed for now!)
    initial_condition_file = Files['initiation_file']
    rundata.qinit_data.qinitfiles.append([1, 2, initial_condition_file]) #   [minlev, maxlev, fname]

    # == setfixedgrids.data values ==
    #fixedgrids = rundata.fixed_grid_data.fixedgrids
    # for fixed grids append lines of the form
    # [t1,t2,noutput,x1,x2,y1,y2,xpoints,ypoints,\
    #  ioutarrivaltimes,ioutsurfacemax]

    return rundata
    # end of function setgeo
    # ----------------------



if __name__ == '__main__':
    # Set up run-time parameters and write all data files.
    import sys
    rundata = setrun(*sys.argv[1:])
    rundata.write()

