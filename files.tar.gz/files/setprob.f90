! setprob.f90 for AVAC 4: version = 1.0
      
      subroutine setprob
      implicit none
      integer :: coulomb
      double precision snow_density, xi, mu, threshold, beta_slope, tau_c
      character*12 fname
      integer iunit
      common /voellmy/ snow_density, xi, mu, threshold, beta_slope, coulomb, tau_c
       
!
!     # read data values for this problem
!
!
      iunit = 7
      fname = 'setprob.data'
!     # open the unit with new routine from Clawpack 4.4 to skip over
!     # comment lines starting with #:
      call opendatafile(iunit, fname)


!     # These parameters are used in src2.f90
      read(7,*) snow_density
      read(7,*) xi
      read(7,*) mu
      read(7,*) threshold
      read(7,*) beta_slope
      read(7,*) coulomb
      read(7,*) tau_c


      close(unit=7)
      print *, 'rho = ',snow_density
      print *, 'xi = ',xi
      print *, 'mu = ',mu
      print *, 'u_* = ',threshold
      print *, 'beta = ',beta_slope
      print *, 'tau_c = ',tau_c
      if (coulomb == 0) then
		print *, 'model = voellmy'
      else
		print *, 'model = coulomb'
      endif
 
      end subroutine setprob
 
